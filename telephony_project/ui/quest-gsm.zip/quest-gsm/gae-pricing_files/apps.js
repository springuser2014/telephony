// Copyright 2009 Google Inc.  All Rights Reserved.

/**
 * @fileoverview Namespace for Google Apps website.
 * @author drewniak
 * modifed by jessicako
 */

/**
 * Namespace for Google Apps website.
 * @type {Object}
 */
var apps = {};

/**
 * Namespace for global variables used on the Apps website.
 * @type {Object}
 */
apps.globals = {};

/**
 * Trims leading and trailing spaces around a string.
 * @return {string} String without leading and trailing spaces.
 */
String.prototype.trim = function() {
  return this.replace(/^\s*|\s*$/, '');
};


/**
 * Stops default browser action.
 * @param {Event} e Event.
 */
apps.stopDefault = function(e) {
  if (e && e.preventDefault) {
    e.preventDefault();
  } else {
    window.event.returnValue = false;
  }
};

/**
 *  Extracts variables from the url based on the specified delimeter.
 * @return {Object} Extracted variables.
 */
apps.parseURLVar = function() {
  var DELIMETERS = ['#', '\\?', '&'];
  var pipe = '|';
  var url = unescape(location.href);
  var arrURL = [];
  var vars = {};
  var tempVar = [];

  for (var i = 0; i < DELIMETERS.length; i++) {
    var regx = new RegExp(DELIMETERS[i], 'ig');
    url = url.replace(regx, pipe);
  }
  arrURL = url.split(pipe);

  for (var i = 1; i < arrURL.length; i++) {
    tempVar = arrURL[i].split('=');
    vars[tempVar[0]] = tempVar[1];
  }

  return vars;
};



/**
 * Extracts current locale info from language dropdown array.
 * @return {Object} object containing domain (.co.jp) and locale (ja).
 */
apps.getLocale = function() {
  if (apps.dropdown.locale) return apps.dropdown.locale;
  if (apps.globals.locale) return apps.globals.locale;

  var langsSize = goog.web.languages.length;

  // Example languages[i]: ['Dansk', '.com', 'da', false]
  for (var i = 0; i < langsSize; i++) {
    if (goog.web.languages[i][3]) {
      var locale = {};
      locale['domain'] = goog.web.languages[i][1];
      locale['lang'] = goog.web.languages[i][2];
      return locale;
    }
  }

  if (!locale) {
    var locale = {
      'domain': '.com',
      'lang': 'en'
    };
  }
  return locale;
};


/**
 * Dynamically localizes links to some outbound sites.
 */
apps.localizeLinks = function() {
  // English, do nothing
  if (apps.globals.locale['lang'] == 'en') {
    return;
  }

  /**
   * List of element ids which need to be localized.
   * 'element id' : 'type of the link (hl, intl)'
   * @type {Object}
   */
  var linkElements = {
    'linkSupport': '\?hl',
    'linkGallery': '&hl'
  };

  /**
   * Languages who's lang codes are different than those of the server.
   * 'lang + linkElements[el]': 'new lang'
   ' 'iw\?hl': 'he'
   */
  var langOverride = {
  };

  var lang = apps.globals.locale['lang'];

  for (var el in linkElements) {
    var currLink = document.getElementById(el);
    var overrideKey = lang + linkElements[el];

    if (linkElements[el] == '\?hl' || linkElements[el] == '&hl') {
      updateHl();
    } else {
      updateIntl();
    }
  }

  /**
   * Appends hl parameter to links.
   */
  function updateHl() {
    if (langOverride[overrideKey]) {
      // Update link with overridden locale info
      try {
        currLink.href += linkElements[el] + '=' + langOverride[overrideKey];
      } catch (e) {
        // Element doesn't exist.
      }
    } else {
      // Update link with currect locale info
      try {
        currLink.href += linkElements[el] + '=' + lang;
      } catch (e) {
        // Element doesn't exist.
      }
    }
  }

  /**
   * Appends or injects intl/xx directory into the path
   */
  function updateIntl() {
    // TODO: add code for changing intl links
  }
};

/**
 * Initializes functions used throughout Apps website.
 * Creates instances of objects used on the website.
 */
apps.setUp = function() {
  apps.dropdown = new goog.web.LangDropdown();
  apps.globals.locale = apps.getLocale();

  //apps.localizeLinks();

};


function changeLanguage(dropdown) {
  if (apps.dropdown) {
    apps.dropdown.changeLanguage(dropdown);
  }
}

/**
 * See if the global namespace object 'goog' exists. If it doesn't, create it.
 */
var goog = goog || {};

/**
 * See if the object goog.web exists. If it doesn't create it.
 */
goog.web = goog.web || {};

/**
 * Language dropdown class.
 * @constructor
 * @param {sting} domain Current domain without .com, .es, .it, etc.
 */
goog.web.LangDropdown = function(domain) {
  this.LANGNAME = 0;
  this.DOMAIN = 1;
  this.LANG = 2;
  this.SELECTED = 3;

  /**
   * Domain of the project to which the dropdown is added to.
   * @type {string}
   */
  this.hostname = goog.web.host || 'google';

  /**
   * Current locale (en, es_es, pl, etc).
   * @type {string}
   */
  this.locale = this.getCurrentLocale();

  this.updateLangArray_();
  this.buildOptions_();
};


/**
 * Redirects user to the proper locale of the page they are on.
 * @param {Element} dropdown Language dropdown.
 */
goog.web.LangDropdown.prototype.changeLanguage = function(dropdown) {
  var selected = dropdown.value;
  var pathname = window.location.pathname;
  var langdropSize = goog.web.languages.length;

  // Find selected language
  for (var i = 0; i < langdropSize; i++) {
    if (goog.web.languages[i][this.LANGNAME] == selected) {
      this.locale.domain = goog.web.languages[i][this.DOMAIN];
      this.locale.lang = goog.web.languages[i][this.LANG];
      break;
    }
  }

  // Construct new host (host + localized domain)
  var host = goog.web.host + this.locale.domain;

  var hasIntl = pathname.match(/(\/intl\/[^\/]*\/)/ig);
  if (hasIntl) {
    pathname = pathname.replace(/(\/intl\/[^\/]*\/)/ig, '/intl/' +
                                this.locale.lang + '/');
  } else {
    pathname = '/intl/' + this.locale.lang + pathname;
  }

  window.location = 'http://' + host + pathname;
};


/**
 * Creates a language dropdown based using goog.web.languages array.
 * @private
*/
goog.web.LangDropdown.prototype.buildOptions_ = function() {
  var dropdown = document.getElementById('f-lang');
  var langdropSize = goog.web.languages.length;

  for (var i = 0; i < langdropSize; i++) {
    var option = document.createElement('option');
    option.value = goog.web.languages[i][this.LANGNAME];
    option.text = goog.web.languages[i][this.LANGNAME];
    option.selected = goog.web.languages[i][this.SELECTED];
    dropdown.options.add(option);
  }
};


/**
 * Modifies language array to flag new language as selected
 * @private
*/
goog.web.LangDropdown.prototype.updateLangArray_ = function() {
  var langdropSize = goog.web.languages.length;

  for (var i = 0; i < langdropSize; i++) {
    if (goog.web.languages[i][this.DOMAIN] == this.locale.domain &&
        goog.web.languages[i][this.LANG] == this.locale.lang) {
      // Both domain and language match entry in the lang array.
      goog.web.languages[i][this.SELECTED] = true;
    } else if (goog.web.languages[i][this.LANG] == this.locale.lang &&
               this.locale.domain == '.com') {
      // Language matches but domain was set to .com (instead for example .fr)
      goog.web.languages[i][this.SELECTED] = true;
    } else {
      // No match
      goog.web.languages[i][this.SELECTED] = false;
    }
  }
};


/**
 * Parses url to get current locale
 * @return {Object} domain (.com) and language ('en').
*/
goog.web.LangDropdown.prototype.getCurrentLocale = function() {
  var path = window.location.pathname;
  var domain = window.location.hostname.replace(this.hostname, '');

  var lang = path.match(/\/intl\/[^\/]*\//ig);
  if (lang) {
    // Found intl/xx
    lang = lang[0].split('/')[2];
  } else if (!lang && domain == '.com') {
    // earth.google.com
    lang = 'en';
  } else {
    // No intl found and domain is not .com
    var langSize = goog.web.languages.length;

    for (var i = 0; i < langSize; i++) {
      lang = 'en';
      if (goog.web.languages[i][this.DOMAIN] == domain) {
        lang = goog.web.languages[i][this.LANG];
        break;
      }
    }
  }

  var locale = {
    'domain': domain,
    'lang': lang
  }
  return locale;
};

/**
 * See if the global namespace object 'goog' exists. If it doesn't, create it.
 */
var goog = goog || {};

/**
 * See if the object goog.web exists. If it doesn't create it.
 */
goog.web = goog.web || {};

goog.web.host = 'www.google';

if (apps && apps.globals) {
  apps.globals.locale = [];
  apps.globals.locale['domain'] = '.com';
  apps.globals.locale['lang'] = 'en';
}

if (window.location.href.indexOf('/edu/') != -1) {
  goog.web.languages = [
    ['Dansk', '.com', 'da', false],
    ['Deutsch', '.com', 'de', false],
    ['\u202A' + 'English (UK)', '.com', 'en-GB', false],
    ['\u202A' + 'English (US)', '.com', 'en', true],
    ['\u202A' + 'español (España)', '.com', 'es', false],
    ['\u202A' + 'español (Latinoamerica)', '.com', 'es-419', false],
    ['suomi', '.com', 'fi', false],
    ['Français', '.com', 'fr', false],
    ['हिन्दी', '.com', 'hi', false],
    ['Italiano', '.com', 'it', false],
    ['日本語', '.com', 'ja', false],
    ['Nederlands', '.com', 'nl', false],
    ['Norsk', '.com', 'no', false],
    ['\u202A' + 'Português (Brasil)', '.com', 'pt-BR', false],
    ['Русский', '.com', 'ru', false],
    ['Svenska', '.com', 'sv', false],
    ['Українська', '.com', 'uk', false],
    ['Tiếng Việt', '.com', 'vi', false],
    ['\u202A' + '中文 (繁體)', '.com', 'zh-TW', false]
  ];
} else {
  // Name, domain, language, selected
  // '\u202A' is added so that parenthesis show up correctly in RTL langs.
  goog.web.languages = [
    ['العربية', '.com', 'ar', false],
    //['български', '.com', 'bg', false],
    //['Català', '.com', 'ca', false],
    ['česky', '.com', 'cs', false],
    ['Dansk', '.com', 'da', false],
    ['Deutsch', '.com', 'de', false],
    //['Ελληνικά', '.com', 'el', false],
    ['\u202A' + 'English (UK)', '.com', 'en-GB', false],
    ['\u202A' + 'English (US)', '.com', 'en', false],
    ['\u202A' + 'English (Australia)', '.com', 'en-au', false],
    ['\u202A' + 'English (India)', '.com', 'en-in', false],
    ['\u202A' + 'English (New Zealand)', '.com', 'en-nz', false],
    ['\u202A' + 'English (Singapore)', '.com', 'en-sg', false],
    ['\u202A' + 'español (España)', '.com', 'es', false],
    ['\u202A' + 'español (Latinoamerica)', '.com', 'es-419', false],
    ['\u202A' + 'español (Argentina)', '.com', 'es-ar', false],
    ['\u202A' + 'español (Chile)', '.com', 'es-cl', false],
    ['\u202A' + 'español (Colombia)', '.com', 'es-co', false],
    ['\u202A' + 'español (México)', '.com', 'es-mx', false],
    ['\u202A' + 'español (Perú)', '.com', 'es-pe', false],
    ['suomi', '.com', 'fi', false],
    ['Français', '.com', 'fr', false],
    ['Filipino', '.com', 'tl', false],
    ['हिन्दी', '.com', 'hi', false],
    ['magyar', '.com', 'hu', false],
    //['hrvatski', '.com', 'hr', false],
    ['Bahasa Indonesia', '.com', 'id', false],
    ['Italiano', '.com', 'it', false],
    ['עברית', '.com', 'iw', false],
    ['日本語', '.com', 'ja', false],
    ['한국어', '.com', 'ko', false],
    //['Latviešu valoda', '.com', 'lv', false],
    //['Lietuvių', '.com', 'lt', false],
    ['Nederlands', '.com', 'nl', false],
    ['Norsk', '.com', 'no', false],
    ['polski', '.com', 'pl', false],
    ['\u202A' + 'Português (Brasil)', '.com', 'pt-BR', false],
    ['\u202A' + 'Português (Portugal)', '.com', 'pt-PT', false],
    //['Română', '.com', 'ro', false],
    ['Русский', '.com', 'ru', false],
    //['Slovenčina', '.com', 'sk', false],
    //['Slovenščina', '.com', 'sl', false],
    //['српски', '.com', 'sr', false],
    ['Svenska', '.com', 'sv', false],
    ['ภาษาไทย', '.com', 'th', false],
    ['Türkçe', '.com', 'tr', false],
    ['Українська', '.com', 'uk', false],
    ['Tiếng Việt', '.com', 'vi', false],
    ['\u202A' + '中文 (简体)', '.com', 'zh-CN', false],
    ['\u202A' + '中文 (繁體)', '.com', 'zh-TW', false]
  ];
}



