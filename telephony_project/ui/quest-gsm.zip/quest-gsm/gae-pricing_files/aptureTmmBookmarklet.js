


(function() {
var B=window.apture,A=window.apture=B||{};

if(!A.isApp){
    A.capabilities=37136;A.aptureConfig={"magicLinks":{"status":207,"logdata":{},"pageid":0,"mlinks":[],"unshown_links":[]}};A.userCookieId="xI9FAkvi5R";A.visitId="5da808fa5d784eb289c563506f4caa8f";A.referer="http://www.google.com/enterprise/cloud/appengine/pricing.html";A.prefs=null;

    A.barColor="#d9ebf8";
    A.barTitleColor="#000";
    A.textShadowColor="#fff";
    A.capabilities = 33024;
    A.siteId = -9999;
}

if (!B){ (function(s){var b=eval("(/*@cc_on!@*/0?(window.XMLHttpRequest/*@cc_on&&@_jscript_version>=5.7@*/?'ie7':null):(window.navigator.userAgent.toLowerCase().search(/iphone|ipad|android|blackberry|windows phone|Firefox\\/2.0/)>-1)?null:(document.childNodes&&!document.all&&!navigator.taintEnabled)?'khtml':(document.getBoxObjectFor||(window.mozInnerScreenX===0||window.mozInnerScreenX))?'gecko':'unk')");if(b){s.type='text/javascript';s.charset='utf-8';s.src="http://cdn.apture.com/media/storage."+b+".v44505253.js";s.defer='true';(document.getElementsByTagName("head").item(0)||document.body).appendChild(s)}})(document.createElement('script')) }
})();
