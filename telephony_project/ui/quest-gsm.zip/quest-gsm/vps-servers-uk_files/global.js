$(window).scroll(function(e){ 
  if ($(this).scrollTop() > 87){ 
    $('#content-top').css({'position': 'fixed', 'top': '0px', 'width': '100%'});
		$('#content-right').css({'position': 'fixed', 'top': '144px', 'width' : '220px'});
		$('#content').css({'margin-top': '114px'});
  }
	
  if ($(this).scrollTop() < 87) { 
    $('#content-top').css({'position': 'static'}); 
		$('#content-right').css({'position': 'static'});
		$('#content').css({'margin-top': '0'});
  }
});
